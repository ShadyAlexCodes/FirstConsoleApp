package edu.neumont;

import edu.neumont.controllers.CreateUsers;

public class Main {

    public static void main(String[] args) {
        CreateUsers createUsers = new CreateUsers();
        createUsers.createUsers();
    }
}
